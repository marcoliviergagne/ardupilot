// auto-generated header, do not edit

#pragma once

#ifndef FORCE_VERSION_H_INCLUDE
#error ap_version.h should never be included directly. You probably want to include AP_Common/AP_FWVersion.h
#endif

#define GIT_VERSION "b7c6bb52"
#define CHIBIOS_GIT_VERSION "a14aa6b0"
